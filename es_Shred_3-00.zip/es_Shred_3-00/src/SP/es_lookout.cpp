// setVars (Energy)
// addEnergy()

#include "es_lookout.h"
#include <cmath>
#include <algorithm>
#include "defs.h"
#include "physDefs.h"
#include "es_world.h"
#include "angleFuncs.h"
#include <iostream>
using namespace std;

es_lookoutList::es_lookoutList() : es_baseEnemList()
{
    
}
void es_lookoutList::setVars(es_world* awor,phlist *aenergy)
{
World=awor;
Energy = aenergy;
}

void es_lookoutList::actSight(std::list<es_baseEnem>::iterator ift, point3f &apoint,int layer)
{
	if(++(ift->Sight.attackDelay) == ift->Sight.CattackDelay)
	{
		addEnergy(ift->body,ift->Theta);
		ift->Sight.attackDelay=0;
	}
}

void es_lookoutList::addEnergy(point3f &abod,float theta){
	phelit *tmpenergy = new phelit;
	tmpenergy->shift.x = cos(theta)*6;
	tmpenergy->shift.z = sin(theta)*6;
	tmpenergy->shift.y = 0;
	tmpenergy->location.x = abod.x + tmpenergy->shift.x;
	tmpenergy->location.z = abod.z + tmpenergy->shift.z;
	tmpenergy->location.y = abod.y;
	tmpenergy->pID = 11;
	Energy->push_back(tmpenergy);
}
