/* Single player enemy with AI set to chase the player and explode on impact.

 */

#ifndef ES_CHASER
#define ES_CHASER

#include <vector>
#include <list>
#include "defs.h"
#include "physDefs.h"
#include "enemyDefs.h"
#include "es_baseEnem.h"
//#include <iostream>

class es_chaserList : public es_baseEnemList{
	public:
	es_chaserList();
	virtual void actSight(std::list<es_baseEnem>::iterator ift,point3f &apoint,int layer);
	virtual void actMem(std::list<es_baseEnem>::iterator ift,point3f &apoint,bool isLayer,bool isWallBet);
};

#endif
