




#include "es_chaser.h"
#include <cmath>
#include <algorithm>
#include "defs.h"
#include "physDefs.h"
#include "es_world.h"
#include "angleFuncs.h"

#include <iostream>
using namespace std;

es_chaserList::es_chaserList() : es_baseEnemList()
{

}


void es_chaserList::actSight(std::list<es_baseEnem>::iterator ift, point3f &apoint,int layer)
{//cout<<"Chase actSight"<<endl;

                        float nx,nz;
                        nx = cos(ift->Theta)*ift->mSpeed;
                        nz = sin(ift->Theta)*ift->mSpeed;
                        ift->body.x += nx;
                        ift->feet.x += nx;
                        ift->body.z += nz;
                        ift->feet.z += nz;
}
void es_chaserList::actMem(std::list<es_baseEnem>::iterator ift, point3f &apoint,bool isLayer,bool isWallBet)
{//cout<<"Chase actMem "<<ift->memory<<endl;
                      //NEED to distinguish between isWallBetween and isOnTopOfWall??
						point2f tmp;
						if(isWallBet)
							tmp = World->bestPath(ift->body,apoint);
                        else
							tmp = apoint;
                        float nx,nz;
                        float anZ,anX,nangle;
                        anZ = tmp.z - ift->body.z;
                        anX = tmp.x - ift->body.x;
                        if(anZ!=0&&anX!=0)
                        {
                            nangle = atan2(anZ,anX);
                            nx = cos(nangle)*ift->mSpeed;
                            nz = sin(nangle)*ift->mSpeed;
							point3f tmp3f = ift->body;
							tmp3f.x +=nx;
							tmp3f.z +=nz;
							if(World->isClear(tmp3f))
							{
								ift->body.x += nx;
								ift->feet.x += nx;
								ift->body.z += nz;
								ift->feet.z += nz;
                            }
                        }
}

