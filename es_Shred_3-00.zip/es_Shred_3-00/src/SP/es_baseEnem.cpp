// setVars (Energy)
// addEnergy()
// memory values, should be setable
// SightWithin and memory handling

#include "es_baseEnem.h"
#include <cmath>
#include <algorithm>
#include "defs.h"
#include "physDefs.h"
#include "es_world.h"
#include "angleFuncs.h"

#include <iostream>
//using namespace std;

es_baseEnem::es_baseEnem(float ax, float ay, float az,float atheta, float aspeed
                       , std::vector<int> alayers, es_idleGest agest) : Sight(-.7,.7,200,50){
    body.x = origSpot.x = ax;
    body.y = origSpot.y = ay+4;
    body.z = origSpot.z = az;
    feet.x = ax;
    feet.y = ay;
    feet.z = az;
	Health=20;
	Theta= origSpot.theta = atheta;
	mSpeed = aspeed;
	Layers=alayers;
	inSight=0;
	Gestures.push_back(es_idleGest(std::vector<es_idle>(),1,NULL));
	Gestures.push_back(agest);
	//if(Gestures.empty())
    //    gestState=-1;
	//else
	gestState=1;
	seeState=0;
	alertState=0;
	alert=0;
	memory=0;
	cMem=100;

}


void es_baseEnem::setVars(es_world *awor)
{
    World=awor;
}

void es_baseEnem::setSight(float aa, float bb, int dist, int adelay, std::vector<es_moving> amove)
{
    es_sight hsight(aa,bb,dist,adelay,amove);
    Sight=hsight;
}

void es_baseEnem::calcGestToOrig(es_orig &aspot)
{
    if(!World->isWallBetween(body,aspot,Layers))
    {
        float xxx,zzz,ccc,axx,azz,tang,att;
        xxx = aspot.x-body.x;
        zzz = aspot.z-body.z;
        ccc = sqrt((xxx*xxx)+(zzz*zzz));
        int tmpcount = ccc/mSpeed;
        tang=atan2(zzz,xxx);
        axx = cos(tang)*mSpeed;
        azz = sin(tang)*mSpeed;
        att = (ang::makeAngle(aspot.theta - Theta))/tmpcount;
        es_idle tmpidle(axx,azz,att,tmpcount);
        
        float tx = aspot.x-(body.x+(axx*tmpcount));
        float tz = aspot.z-(body.z+(azz*tmpcount));
        es_idle tmpidle2(tx,tz,0,1);
        
        std::vector<es_idle> agest;
        if(tmpcount>0)
        {
            agest.push_back(tmpidle);
            agest.push_back(tmpidle2);
        }
        else
        {
            agest.push_back(tmpidle2);
            float tatt = (ang::makeAngle(aspot.theta-Theta))/40;
            es_idle tmpidleatt(0,0,tatt,40);
            agest.push_back(tmpidleatt);
        }
        //es_idleGest tmpgest(agest,1,new Stand());
        Gestures[0].Idles = agest;
        Gestures[0].iiIdle = 0;
        gestState=0;
    }
    else
    {
        point2f tmp2f;
        point2f tmpbody = body;
        std::vector<es_idle> agest;
        int loopCount=0;
        while(World->isWallBetween(tmpbody,aspot,Layers))
        {
        if(++loopCount==5)
        {	cout<<"BREAKLOOP"<<endl;
			break;
        }
            tmp2f = World->bestPath(tmpbody,aspot);
            float xxx,zzz,ccc,axx,azz,tang;
            xxx = tmp2f.x-tmpbody.x;
            zzz = tmp2f.z-tmpbody.z;
            ccc = sqrt((xxx*xxx)+(zzz*zzz));
            int tmpcount = ccc/mSpeed;
            tang=atan2(zzz,xxx);
            axx = cos(tang)*mSpeed;
            azz = sin(tang)*mSpeed;
            //	att = (ang::makeAngle(aspot.theta - Theta))/tmpcount;
            es_idle tmpidle(axx,azz,0,tmpcount);
            
            float tx = tmp2f.x-(tmpbody.x+(axx*tmpcount));
            float tz = tmp2f.z-(tmpbody.z+(azz*tmpcount));
            es_idle tmpidle2(tx,tz,0,1);
            
            if(tmpcount>0)
            {
                agest.push_back(tmpidle);
                agest.push_back(tmpidle2);
            }
            else
            {
                agest.push_back(tmpidle2);
            }
            tmpbody=tmp2f;
        }
        float xxx,zzz,ccc,axx,azz,tang,att;
        xxx = aspot.x-tmpbody.x;
        zzz = aspot.z-tmpbody.z;
        ccc = sqrt((xxx*xxx)+(zzz*zzz));
        int tmpcount = ccc/mSpeed;
        tang=atan2(zzz,xxx);
        axx = cos(tang)*mSpeed;
        azz = sin(tang)*mSpeed;
        att = (ang::makeAngle(aspot.theta - Theta))/tmpcount;
        es_idle tmpidle(axx,azz,att,tmpcount);
        
        float tx = aspot.x-(tmpbody.x+(axx*tmpcount));
        float tz = aspot.z-(tmpbody.z+(azz*tmpcount));
        es_idle tmpidle2(tx,tz,0,1);
        
        if(tmpcount>0)
        {
            agest.push_back(tmpidle);
            agest.push_back(tmpidle2);
        }
        else
        {
            agest.push_back(tmpidle2);
            float tatt = (ang::makeAngle(aspot.theta-Theta))/40;
            es_idle tmpidleatt(0,0,tatt,40);
            agest.push_back(tmpidleatt);
        }
        
        //es_idleGest tmpgest(agest,1,NULL);
        Gestures[0].Idles = agest;
        Gestures[0].iiIdle = 0;
        gestState=0;
    }
}
void es_baseEnemList::wasAlerted(std::list<es_baseEnem>::iterator ift,point3f &apoint)
{		if(ift->alertState==0)
			ift->alertState=1;
		ift->alert = ift->cMem;
}
void es_baseEnemList::actSight(std::list<es_baseEnem>::iterator ift, point3f &apoint,int layer)
{

}
void es_baseEnemList::actMem(std::list<es_baseEnem>::iterator ift, point3f &apoint,bool isLayer,bool isWallBet)
{

}

void es_baseEnemList::actIdle(std::list<es_baseEnem>::iterator ift)
{
	if(ift->gestState==-1)//Gestures is empty
        return;
	else if (ift->gestState==0 || ift->gestState==1)
	{
        ift->body.x += ift->Gestures[ift->gestState].Idles.at(ift->Gestures[ift->gestState].iiIdle).x;
        ift->feet.x += ift->Gestures[ift->gestState].Idles.at(ift->Gestures[ift->gestState].iiIdle).x;
        ift->body.z += ift->Gestures[ift->gestState].Idles.at(ift->Gestures[ift->gestState].iiIdle).z;
        ift->feet.z += ift->Gestures[ift->gestState].Idles.at(ift->Gestures[ift->gestState].iiIdle).z;
        ift->Theta =  ang::makeAngle(ift->Theta + ift->Gestures[ift->gestState].Idles.at(ift->Gestures[ift->gestState].iiIdle).Theta);
        if(++(ift->Gestures[ift->gestState].Idles.at(ift->Gestures[ift->gestState].iiIdle).count) == ift->Gestures[ift->gestState].Idles.at(ift->Gestures[ift->gestState].iiIdle).constcount)
        {
            ift->Gestures[ift->gestState].Idles.at(ift->Gestures[ift->gestState].iiIdle).count=0;
            if(++(ift->Gestures[ift->gestState].iiIdle) == ift->Gestures.at(ift->gestState).Idles.size())
            {   ift->Gestures[ift->gestState].iiIdle=0;
                ift->gestState=ift->Gestures.at(ift->gestState).nextGest;
            }
        }
 	}
 	else
 	cout<<"gestState does not equal zero or one!!!!"<<endl;
}

void es_baseEnem::fixSpeed(float amt)
{
    float tmpcountratio = (float)Gestures.at(gestState).Idles.at(Gestures[gestState].iiIdle).count
						 / (float)Gestures.at(gestState).Idles.at(Gestures[gestState].iiIdle).constcount;
    std::vector<es_idleGest>::iterator gi;
	for(gi=Gestures.begin();gi!=Gestures.end();gi++)
	{
		gi->fix(amt);
	}
    // calculate new count (as of this writing the end spot will be off by up to 1)
    Gestures.at(gestState).Idles.at(Gestures[gestState].iiIdle).count
		 = tmpcountratio * Gestures.at(gestState).Idles.at(Gestures[gestState].iiIdle).constcount;
}
void es_baseEnemList::saveSpot(std::list<es_baseEnem>::iterator ift){
ift->lastSpot.x=ift->body.x;
ift->lastSpot.z=ift->body.z;
ift->lastSpot.y=ift->body.y;
ift->lastSpot.theta=ift->Theta;
}

void es_baseEnemList::justSpotted(std::list<es_baseEnem>::iterator ift){

}
void es_baseEnemList::spottedInMem(std::list<es_baseEnem>::iterator ift){

}
void es_baseEnemList::leftSight(std::list<es_baseEnem>::iterator ift){

}
void es_baseEnemList::leftMem(std::list<es_baseEnem>::iterator ift){
if(ift->alertState==0)
	ift->calcGestToOrig(ift->lastSpot);
}
void es_baseEnemList::justAlert(std::list<es_baseEnem>::iterator ift){

}
void es_baseEnemList::leftAlert(std::list<es_baseEnem>::iterator ift){
if(ift->seeState==0)
	ift->calcGestToOrig(ift->lastSpot);
}

void es_baseEnemList::action()
{
	std::list<es_baseEnem>::iterator ii=Units.begin();
	while(ii!=Units.end())
	{
		if(ii->Health<=0)
		{
            loc_customf *tmpexp = new loc_customf;
            tmpexp->location = ii->feet;
            tmpexp->custom = 0;
            colList.push_back(tmpexp);
            ii=Units.erase(ii);
		}
		else
            ++ii;
	}
}

es_baseEnemList::es_baseEnemList()
{
    
}

es_baseEnemList::~es_baseEnemList()
{

}
void es_baseEnemList::setVars(es_world *awor)
{
    World=awor;
}


void es_baseEnemList::push_back(es_baseEnem abaseEnem)
{// add a unit to this container
    abaseEnem.setVars(World);
    Units.push_back(abaseEnem);
    //cout<<"MEM = "<<abaseEnem.memory<<endl;
}
bool es_baseEnemList::Damage(point3f &apoint,int prox,float dmg)
{// Damage first unit within proximity
    std::list<es_baseEnem>::iterator ii=Units.begin();
    for(ii;ii!=Units.end();ii++)
    {
        float tmpx,tmpy,tmpz;
        tmpx = fabs(apoint.x - ii->body.x);
        tmpz = fabs(apoint.z - ii->body.z);
        tmpy = fabs(apoint.y - ii->body.y);
        if(tmpx < 50 && tmpz < 50 && tmpy < 50)
        {
            if(tmpx < prox && tmpz < prox && tmpy < prox)
            {	ii->Health-=dmg;
				wasAlerted(ii,apoint);
                return 1;
            }
            tmpx = fabs(apoint.x - ii->feet.x);
            tmpz = fabs(apoint.z - ii->feet.z);
            tmpy = fabs(apoint.y - ii->feet.y);
            if(tmpx < prox && tmpz < prox && tmpy < prox)
            {	ii->Health-=dmg;
				wasAlerted(ii,apoint);
                return 1;
            }
        }
    }
    return 0;
}
void es_baseEnemList::AllDamage(point3f &apoint,int prox,float dmg)
{// Damage all Units within proximity
    std::list<es_baseEnem>::iterator ii=Units.begin();
    for(ii;ii!=Units.end();ii++)
    {
        float tmpx,tmpy,tmpz;
        tmpx = fabs(apoint.x - ii->body.x);
        tmpz = fabs(apoint.z - ii->body.z);
        tmpy = fabs(apoint.y - ii->body.y);
        if(tmpx < 50 && tmpz < 50 && tmpy < 50)
        {
            if(tmpx < prox && tmpz < prox && tmpy < prox)
            {	ii->Health-=dmg;
				wasAlerted(ii,apoint);
                continue;
            }
            tmpx = fabs(apoint.x - ii->feet.x);
            tmpz = fabs(apoint.z - ii->feet.z);
            tmpy = fabs(apoint.y - ii->feet.y);
            if(tmpx < prox && tmpz < prox && tmpy < prox)
            {	ii->Health-=dmg;
				wasAlerted(ii,apoint);
                continue;
            }
        }
    }
}

bool es_baseEnemList::Slow(point3f &apoint, int prox,float amt,float ttimer){
    std::list<es_baseEnem>::iterator ii=Units.begin();
    for(ii;ii!=Units.end();ii++)
    {
        float tmpx,tmpy,tmpz;
        tmpx = fabs(apoint.x - ii->body.x);
        tmpz = fabs(apoint.z - ii->body.z);
        tmpy = fabs(apoint.y - ii->body.y);
        if(tmpx < 50 && tmpz < 50 && tmpy < 50)
        {
            if(tmpx < prox && tmpz < prox && tmpy < prox)
            {	ii->mSpeed*=amt;
				ii->fixSpeed(amt);
				wasAlerted(ii,apoint);
                return 1;
            }
            tmpx = fabs(apoint.x - ii->feet.x);
            tmpz = fabs(apoint.z - ii->feet.z);
            tmpy = fabs(apoint.y - ii->feet.y);
            if(tmpx < prox && tmpz < prox && tmpy < prox)
            {	ii->mSpeed*=amt;
				ii->fixSpeed(amt);
				wasAlerted(ii,apoint);
                return 1;
            }
        }
    }
    return 0;
}

void es_baseEnemList::SightWithin(point3f &apoint,int layer)
{
std::list<es_baseEnem>::iterator ift = Units.begin();
for(ift;ift!=Units.end();ift++)
{
			float avZ,avX,avgle,avist;
			avZ = apoint.z - ift->body.z;
			avX = apoint.x - ift->body.x;
			avgle = atan2(avZ,avX);
			avist = avZ/sin(avgle);
            float A1,B1;
            bool isWallBet =  World->isWallBetween(ift->body, apoint,ift->Layers);
            bool isSameLayer = (ift->Layers.end() != std::find(ift->Layers.begin(),ift->Layers.end(),layer));
            A1=ang::makeAngle(ift->Theta+ift->Sight.A);
            B1=ang::makeAngle(ift->Theta+ift->Sight.B);


            // See if avatar is within this sight
            if( ang::angleWithin(avgle,A1,B1) && avist <= ift->Sight.dist
                && isSameLayer && 0==isWallBet )
            {//in sight
				if(ift->seeState==0)
				{//spotted for first time
					if(ift->gestState==1 && ift->alertState==0)
						saveSpot(ift);
					ift->seeState=1;
					justSpotted(ift);
				}
				else if(ift->seeState==1 || ift->seeState==5)// || ift->seeState==9)
				{	ift->seeState=2;//is in sight, not first spot

				}
				else if(ift->seeState==4)
				{	ift->seeState=5;//spotted while in memory
					spottedInMem(ift);
				}
				ift->inSight=1;
				ift->memory = ift->cMem;
				//ift->gestState = 2;
            }
            else
            {//not in sight
				ift->inSight=0;
				if(ift->seeState==1 || ift->seeState==2)
				{	ift->seeState=4;//leaving sight, still in memory
					leftSight(ift);
				}
				//else if(ift->seeState==3)
				//	ift->seeState=4;//in memory, not in sight
            }

			if(ift->alertState==1)
			{	if(ift->gestState==1 && ift->seeState==0)
					saveSpot(ift);
				ift->Theta=avgle;
				ift->alertState=2;
				//ift->alert=ift->cMem;
				justAlert(ift);
			}
			else if( ift->alertState==2 )
			{
				ift->Theta=avgle;
				if(--ift->alert==0)
				{	ift->alertState=0;
					leftAlert(ift);
				}
			}

            if(ift->memory!=0)
			{//in memory

                if(--ift->memory == 0)
				{//just left memory
					ift->seeState=0;//leaving memory
					leftMem(ift);
				}
				else if(ift->inSight)
				{	actSight(ift,apoint,layer);
					ift->Theta=avgle;
				}
				else
				{
					actMem(ift,apoint,isSameLayer,isWallBet);
				}
            }
            else // Do this if avatar is not in sight
			{//not in
				ift->seeState=0;
				if(ift->alertState==0)
				actIdle(ift);
			}
}
}
