/* Used on Windows platform.

 */
#ifndef WINDEFS
#define WINDEFS

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

#endif
